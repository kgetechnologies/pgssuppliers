<?php 
header("Content-type: text/xml");
?>


<urlset xmlns="http://www.google.com/schemas/sitemap/0.84" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.google.com/schemas/sitemap/0.84 http://www.google.com/schemas/sitemap/0.84/sitemap.xsd">

    <url>
        <loc>http://www.pgssuppliers.co.uk/</loc>
        <changefreq>daily</changefreq>
    </url>

    <?php
    
    $urls= array("","clients.html","products-cements.html","products-m-sand.html","products-blue-metal.html","products-kerb-stones.html","products-solid-blocks.html","products-paver-blocks.html","products.html","about-us.html","index.html","projects.html","services.html","contact-us.html");
reset($urls);

while (list($key, $val) = each($urls))
{
    ?>
    <url>
        <loc>http://www.pgssuppliers.in/<?php echo "$val" ?></loc>
        <changefreq>daily</changefreq>
        <priority>0.5</priority>
    </url>

 <?php } ?>

</urlset>